sitec systems GmbH fork of [CanFestival](http://dev.automforge.net/CanFestival-3) based on the fork of [mongo](https://bitbucket.org/Mongo/canfestival-3-asc). Contains changes which are not merged to the mainline code. This is although used as backup for the public code.

sitec sytems GmbH - [http://wwww.sitec-systems.de](http://wwww.sitec-systems.de)

