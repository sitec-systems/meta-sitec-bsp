#!/bin/sh

/bin/sh insert.sh

console/canf_ktest_console

/bin/sh remove.sh
